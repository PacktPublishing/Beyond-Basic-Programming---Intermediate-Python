from math import sqrt 

def something(x): 
    return x * x 


if __name__ == '__main__': 
    something() 
    
    